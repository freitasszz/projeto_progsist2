# webservice-empresas-estudantes-vagas

Projeto Spring Boot (starter web) gerando um Web Service REST para gerenciar EMPRESAS, ESTUDANTES e VAGAS.
Pacote base usado: com.progsist2.projeto

Como usar:
1. Abra em Codespaces / VSCode.
2. Rode `mvn spring-boot:run` ou execute a aplicação pelo IDE.
3. Os arquivos de teste REST estão em `src/main/resources/http/` (use REST Client extension).
